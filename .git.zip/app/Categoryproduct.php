<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Categoryproduct extends Model
{
     protected $table ="category_product";
}
