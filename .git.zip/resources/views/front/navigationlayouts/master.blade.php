@include('front.navigationlayouts.header')

@yield('content')

@include('front.navigationlayouts.footer')