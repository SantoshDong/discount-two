
<?php $__env->startSection('content'); ?>
<div class="container">
        <div class="row">
     
            <div class="col-lg-4 __cate">
            
              <div class="text-center" style="width:100%;padding:10px;background: #f1f1f1;">
                <label for="inputState" style="font-weight:600;font-size:1em;letter-spacing:.1em;">Categories</label>
              </div>
                <div class="form-group" style="background-color:#ffffff;padding: 20px 10px;">
                  <select id="hide" class="form-control categoryid">
                    <option selected>Choose...</option>
                    <?php $__currentLoopData = App\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if(strtolower($name) == strtolower($category->category_name)): ?>
                      <option value="<?php echo e($category->id); ?>" selected=""><?php echo e($category->category_name); ?></option>
                    <?php else: ?>
                      <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                    <?php endif; ?>
                  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </select>
                </div>
            </div>

            <div class="col-lg-8 bg-dark" style="padding-top:10px;padding-bottom:10px;">
                <div class="fl fw s_cat_r_d text-center">
                    <h1 id="categoryName_hd" class="hd_1">Discount Offers </h1>
                    <p id="categoryCoupons_text">Coupon Codes &amp; mero discount  (20) </p>
                </div>
            </div>
        </div>
    </div>
    <!--popularity div starts here-->
    <div class="container" style="margin-top:10px;margin-bottom: 60px;" id="product">

        <?php if($products->count() > 0): ?>

          <?php if(isset($name) && isset($location)): ?>
            <div  class="ra">

             <h4 style="color:#111111;margin-top: 30px;"><?php echo e($products->count()); ?> Result Found for "<?php echo e($name); ?>" & "<?php echo e($location); ?>"</h4>
            </div>
           <?php endif; ?>
          <div class="row __content wrapperdata" style="margin-top:4%;">
        
          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 col-sm-6 col-12" style="margin-bottom:14px;">
              <div class="card" style="margin-bottom:10px;width:100%;margin:.5%;height:275px">
                
                <div class="card-body">
                    
                    <div class="card-image">
                        <img style="height:8em;width:60%;" class="card-img-top" src="/storage/<?php echo e($product->logo); ?>" alt="Card image cap">
                    </div>
                    <div class="row name">
                        <div class="col-2">
                            <i class="fa fa-user" style="font-size:20px"></i>
                        </div>
                        <div class="col-9">
                            <span class="__card-overflow"><?php echo e($product->name); ?></span>
                        </div>
                    </div>
                    <div class="row place">
                       <div class="col-2">
                            <i class="fa fa-address-book" style="font-size:20px"></i>
                       </div>
                        <div class="col-9">
                            <span class="__card-overflow"><?php echo e($product->address); ?></span>
                        </div>
                    </div>
                    <div class="row phone-no">
                        <div class="col-2">
                            <i class="fa fa-phone" style="font-size:20px"></i>
                        </div>
                        <div class="col-9">
                            <span class="__card-overflow"><?php echo e($product->contact_nbr); ?></span>
                        </div>
                    </div>
                </div>
            </div>
            </div>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php else: ?>
          <?php if(isset($name) && isset($location)): ?>
          <div  class="ra">
             <h4 style="color:#111111;margin-top: 30px;"> No Result Found for "<?php echo e($name); ?>" & "<?php echo e($location); ?>"</h4>
          </div>
          else
          <div  class="ra">
             <h4 style="color:#111111;margin-top: 30px;"> No Result Found</h4>
          </div>
          <?php endif; ?>
        <?php endif; ?>
            
        </div>
    </div>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
   <script>
     $(document).ready(function(){
     $("#hide").change(function(){
      $categoryid=$(".categoryid").val();
      $.ajax({ 
      method:'GET',
      url:'<?php echo e(url("categoryproduct")); ?>'+"/"+$categoryid,
        success: function(data){    
      $(".wrapperdata").html(data);
      console.log(data);
     
       }
         });
      });
    });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', ['title' =>$name. ' - Mero Discount'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/merodisc/laravel/resources/views/front/home/categorysearch.blade.php ENDPATH**/ ?>