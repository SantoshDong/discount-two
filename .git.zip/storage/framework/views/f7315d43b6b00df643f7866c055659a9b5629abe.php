<?php echo $__env->make('admin.layouts.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>

<?php echo $__env->make('admin.layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if(auth()->guard()->check()): ?>
<?php echo $__env->yieldContent('content'); ?>
<?php else: ?>

<?php endif; ?>
      



       


</div>
       
    </div><!-- /#right-panel -->



    <!-- Right Panel -->
<?php echo $__env->make('admin.layouts.bottom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/merodisc/laravel/resources/views/admin/layouts/master.blade.php ENDPATH**/ ?>