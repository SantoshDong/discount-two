

<?php $__env->startSection('content'); ?>
    <!--first navbar content ends here-->

<style>
#__top-categor,.__travel-offer{
      overflow:hidden;
      margin-top:3em;
      max-width:1170px!important;
      margin-left:105px;
}
.__forallimg img{
    height:7em;
    width:60%!important;
    margin:0 auto;
}
    @media  only screen and (max-width:767px){
      #__top-categor,.__travel-offer{
      margin-left:8px!important;
  }
  .__forallimg img{
      width:50%!important;
  }
  .owl-nav .owl-prev span, .owl-nav .owl-next span {
    font-size: 40px;
    text-decoration: none;
    outline: 0;
}
    }
</style>

    <div class="container-fluid tab-container mobile-container" style="margin-top:5px;">
        <div class="container">
            <div class="row" style="background-color:#fff;">
                <div class="col-lg-4 col-md-5 col-sm-6 __for-checkout" style="padding-left:0px;background-color:#32CD32;">
                    <div class="checkout-progress-sidebar ">
                        <div class="panel-group">
                            <div class="panel panel-default" style="padding: 19px 15px;">
                                <div>
                                    <h4 class="unicase-checkout-title"
                                        style="color: #ffffff; font-weight: 700; text-align: center;letter-spacing:.1rem;">
                                        Benefits !</h4>
                                </div>
                                <div class="">
                                    <ul class="nav nav-checkout-progress list-unstyled inlist">
                                        <li><span>1</span> Nepal's Fastest Growing Hidden Discount Deals on Offline
                                            &amp; Online Shopping.</li>
                                        <li><span>2</span> Nepal's First Money Saving Discount Card With Highest
                                            Merchant Partners</li>
                                        <li><span>3</span> Start Saving Money Right From Today Itself, Become Our
                                            Premium Member</li>
                                        <li><span>4</span> Get Access To Thousands Of Multicuisine Restaurants, Beauty, SPA's, GYM's &amp; More</li>
                                            <li><span>5</span> Get Started Right Form Now By Saving Money Using Our Discount Card</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8 col-md-7 col-sm-6 __for-slider-img" style="padding-right:0px;">
                    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img style="height: 380px;width:100%" class="img-fluid" src="<?php echo e(asset('images/hero-san.jpg')); ?>"
                                    alt="First slide">
                            </div>
                            <div class="carousel-item">
                                <img style="height: 380px;width:100%" class="img-fluid" src="<?php echo e(asset('images/hero-san.jpg')); ?>"
                                    alt="Second slide">
                            </div>
                            <div class="carousel-item">
                                <img style="height: 380px;width:100%" class="img-fluid" src="<?php echo e(asset('images/hero-san.jpg')); ?>"
                                    alt="Third slide">
                            </div>
                        </div>
                        <a class="carousel-control-prev" href="#carouselExampleControls" role="button"
                            data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#carouselExampleControls" role="button"
                            data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!--Top Categories Starts Here-->
    <div class="container __top-categor" id="__top-categor">
        <div class="row __for-heading" style="margin-bottom:.3rem;">
            <h4 class="txt20" style="padding:.3em 0em; font-weight:600;letter-spacing:1px;font-size:20px;font-size:18px;">Top Catogories</h4>
        </div>
        <div class="row owl-carousel owl-theme">
           
           <?php $__currentLoopData = App\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <a href="<?php echo e(url('product/'.str_replace(' ','-',$category->category_name))); ?>" style="text-decoration:none;"> 
           <div class="item" style="background:#ffffff">
                <div class="row" style="margin-left:0px;marin-right:0px;display:block;">
                    <div class="__forallimg" style="text-align:center;">
                        <img style="" src="/storage/<?php echo e($category->logo); ?>" height="14px" width="14px">
                    </div>
                    <div class="">
                        <span class="category-text"><?php echo e($category->category_name); ?></h5>
                    </div>
                </div>
            </div>
           </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </div>
    <!--Our Top Catogories Ends Here-->
    <!--Travel Offer Slider start here-->
    <div class="container __travel-offer">
        <div class="row __for-heading" style="margin-bottom:.3rem;">
            <h4 class="txt20" style="padding:.3em 0em;font-weight:600;letter-spacing:1px;font-size:20px;font-size:18px;">We Offer Nepal's Best Discount Deals</h4>
        </div>
        <div class="row owl-carousel owl-theme">
        <?php $__currentLoopData = App\Travel::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $travel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item" style="background:#ffffff">
                <div class="row">
                    <div class="col-12 __forallimg" style="width:50%;margin:0 auto;">
                        <img style="height:8em;width:60%;margin:0 auto;"  src="/storage/<?php echo e($travel->logo); ?>">
                    </div>
                    <div class="col-12">
                        <span class="travel-text text-center"><?php echo e($travel->title); ?></span>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <!--Our Travel section Ends Here-->
     <!--recently added Starts Here-->

     <div class="container" style="overflow:hidden;margin-top:3em;">
        <div class="row __for-heading" style="margin-bottom:.3rem;display: flex;">
            <h4 class="txt20" style="padding:.3em 0em;font-weight:600;letter-spacing:1px;font-size:18px;flex-grow: 1;">Recently Deals</h4>
            <!--<a href="<?php echo e(url('/product')); ?>" style="color: gray;margin-top: 4px;">VIEW ALL</a>-->
        </div>
       
        <div class="row owl-recently owl-theme">
        <?php $__currentLoopData = App\Recent::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card" style="margin-bottom:10px;width:100%;margin:.5%;height:275px">
                            <img style="height:8em;width:60%;margin:0 auto;" class="card-img-top" src="/storage/<?php echo e($recent->logo); ?>" alt="Card image cap">
                            <div class="card-body">
                                <div class="row name">
                                    <div class="col-2">
                                        <i class="fa fa-user" style="font-size:20px"></i>
                                    </div>
                                    <div class="col-9">
                                        <span class="__card-overflow"><?php echo e($recent->title); ?></span>
                                    </div>
                                </div>
                                <div class="row place">
                                   <div class="col-2">
                                        <i class="fa fa-address-book" style="font-size:20px"></i>
                                   </div>
                                    <div class="col-9">
                                        <span class="__card-overflow"><?php echo e($recent->address); ?></span>
                                    </div>
                                </div>
                                <div class="row phone-no">
                                    <div class="col-2">
                                        <i class="fa fa-phone" style="font-size:20px"></i>
                                    </div>
                                    <div class="col-9">
                                        <span class="__card-overflow"><?php echo e($recent->contact_nbr); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            

        </div>
    </div>
    <!--recently added Ends Here-->
    <!--Our Brands Section Starts Here-->
    
    <div class="container" style="overflow:hidden;margin-top:3em;margin-bottom:5em;">
        <div class="row __for-heading" style="margin-bottom:.3rem;">
            <h4 class="txt20" style="padding:.3em 0em;font-weight:600;letter-spacing:1px;font-size:18px;">Recent Merchants</h4>
        </div>
        <div class="row owl-brand owl-theme" style="height:9em;border-radius:50%;">
          <?php $__currentLoopData = App\Brand::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
                <div class="row" style="padding:0px;">
                    <div class="col-12" style="width:50%;text-align:center;">
                        <img style="border-radius:50%;height:9em;" class="img-fluid" src="/storage/<?php echo e($brand->brand_logo); ?>">
                    </div>
                </div>
            </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          

        </div>
    </div>
    <!--Our Brnds Section Ends Here-->
    <!--1 million like start here-->
    <div class="container" style="overflow:hidden">
        <div class="row __for-heading" style="margin-bottom:.3rem;">
            <h4 class="txt20" style="padding:.3em 0em;font-weight:600;letter-spacing:1px;font-size:18px;">Why 1 Million People Like US?</h4>
        </div>
        <div class="row owl-like owl-theme">
            <div class="item">
                <div class="row">
                    <div class="col-12 like-img" style="text-align:center;padding-top:5px;">
                         <img style="height:125px;width:125px;border-radius:50%;" src="<?php echo e(asset('images/listing1.jpg')); ?>">
                    </div>
                    <div class="col-12 like-heading text-center">
                         <h5>Popularity</h5>
                    </div>
                    <div class="col-12 like-description text-center">
                         <p>we are popular all over the world!</p>
                    </div>
             </div>
            </div>
            <div class="item">
                <div class="row">
                    <div class="col-12 like-img" style="text-align:center;padding-top:5px;">
                        <img style="height:125px;width:125px;border-radius:50%;" src="<?php echo e(asset('images/listing1.jpg')); ?>">
                    </div>
                    <div class="col-12 like-heading text-center">
                         <h5>Branch world wide</h5>
                    </div>
                    <div class="col-12 like-description text-center">
                         <p>we are popular all over the world!</p>
                    </div>
             </div>
            </div>
            <div class="item">
                <div class="row">
                    <div class="col-12 like-img" style="text-align:center;padding-top:5px;">
                        <img style="height:125px;width:125px;border-radius:50%;" src="<?php echo e(asset('images/listing1.jpg')); ?>">
                    </div>
                    <div class="col-12 like-heading text-center">
                         <h5>Trust</h5>
                    </div>
                    <div class="col-12 like-description text-center">
                         <p>we are popular all over the world!</p>
                    </div>
             </div>
            </div>
            <div class="item">
                <div class="row">
                    <div class="col-12 like-img" style="text-align:center;padding-top:5px;">
                        <img style="height:125px;width:125px;border-radius:50%;" src="<?php echo e(asset('images/listing1.jpg')); ?>">
                    </div>
                    <div class="col-12 like-heading text-center">
                         <h5>Huge Discount</h5>
                    </div>
                    <div class="col-12 like-description text-center">
                         <p>we are popular all over the world!</p>
                    </div>
             </div>
            </div>
            
            

        </div>
    </div>
    <!--1 million like ends here-->
    <!--Testimonial Starts Here-->

    <div class="container" style="overflow:hidden;margin-top:3em;">
        <div class="row __for-heading" style="margin-bottom:.3rem;">
            <h4 class="txt20" style="padding:.3em 0em;font-weight:600;letter-spacing:1px;font-size:18px;">Testimonial</h4>
        </div>
       
        <div class="row owl-testimonial owl-theme">
            <?php $__currentLoopData = App\Client::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item" style="background-color:#ffffff">
                <div class="row" style="padding:0px;margin:0px;">
                    <div class="col-12" style="width:50%;text-align:center;padding:.7em;">
                        <p class="__for-overflow"><?php echo e($client->description); ?>

                            </p>
                        <h5 style="text-align:center;">- <?php echo e($client->name); ?></h5>
                    </div>
                </div>
            </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            

        </div>
    </div>
    <!--Testimonial Ends Here-->
    <!--media coverage Starts here-->
    <div class="container" style="overflow:hidden;margin-top:3em;">
        <div class="row __for-heading" style="margin-bottom:.3rem;">
            <h4 class="txt20" style="font-weight:600;letter-spacing:1px;font-size:18px;">Media coverage</h4>
        </div>
        <div class="row owl-media owl-theme">
            <?php $__currentLoopData = App\Coverage::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mediacovergae): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item" style="padding:10px;">
                <div class="row" style="background-color:beige;margin-left:1px;margin-right:1px;">
                    <div class="col-md-5 col-4 __media-img">
                        <img class="img-fluid" src="/storage/<?php echo e($mediacovergae->logo); ?>">
                    </div>
                    <div class="col-md-7 col-8">
                        <h1 style="font-size:20px;font-weight:500;"><?php echo e($mediacovergae->title); ?></h1>
                        <!-- <p>2Lorem ipsum dolor sit, amet consectetur adipisicing elitosam quis!</p> -->
                    </div>
                    <div class="col-md-12 col-12">
                        <p class="__text-limit">

                          <?php echo e($mediacovergae->description); ?>   
                            </p>
                    </div>
                </div>
                <div class="row ml-0">
                   <a href="<?php echo e($mediacovergae->url); ?>"><button type="button" class="btn" style="background:#fdb515;">Read Topics<button></a>
                </div>
            </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
    <!--end of media coverage-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master',['title'=>'Mero Discount'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/merodisc/laravel/resources/views/front/home/index.blade.php ENDPATH**/ ?>