
<?php $__env->startSection('content'); ?>
  

<div class="animated fadeIn">
<div class="row">
                <!-- <div class="col-md-1">
                </div> -->
                <div class="col-md-12">

       <?php if(session()->has('success')): ?>

          <div class="alert alert-success alert-dismissible">
           <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <strong><?php echo e(session()->get('success')); ?></strong> 
             </div>


<?php endif; ?>
</div>
</div>

<div class="row">
  <div class="col-lg-12">
    <div class="card">
        <div class="card-header">
            <strong class="card-title">View single Media data</strong>
        </div>
        <div class="card-body">
          <!-- Credit Card -->
          <div id="pay-invoice">
              <div class="card-body">
               
                  <form action="" method="" novalidate="novalidate" enctype="multipart/form-data">
                

                     <h5>Title:</h5>
                     <div class="card">
  <div class="card-body">
  <?php echo e($coverage->title); ?>

  </div>
</div>

<h5>Url:</h5>
                     <div class="card">
  <div class="card-body">
  <?php echo e($coverage->url); ?>

  </div>
</div>

<h5>Description:</h5>
                     <div class="card">
  <div class="card-body">
  <?php echo e($coverage->description); ?>

  </div>
</div>




                  </form>
                  <div class="group">
               <a href="<?php echo e(route('coverage.index')); ?>"><button type="submit" class="btn btn-primary">Back</button></a>
                      </div>
                      

              </div>
          </div>

        </div>






    </div> <!-- .card -->

  </div><!--/.col-->


</div>



</div>

<script>
$(document).ready(function(){
$("#type").click(function(){
$("$image").hide();

});

});

</script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/merodisc/laravel/resources/views/admin/news/view.blade.php ENDPATH**/ ?>