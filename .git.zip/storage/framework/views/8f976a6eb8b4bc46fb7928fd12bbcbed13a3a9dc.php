

<?php $__env->startSection('content'); ?>
    <!--About Us Section Starts Here-->
   

            <div class="container">
                <div class="row" style="background: #b3b3b3;margin-bottom:.3rem;">
                    <h3 style="margin:0 auto;padding:.3em 0em">Contact Us</h3>
                </div>
               <div class="row">
                  
                  <div class="col-md-12">
                     <p>For further details please call our Liason Office @ Muncha.com</p>
                </div>
                <div class="col-md-12">
                     <p>Contact Person: Mr. Rishi Shrestha:   9801051051,  01-5539414 / 5535757</p>
                </div>
                <div class="col-md-12">
                     <p>Mani Maharjan:    9801039413></p>
                </div>
                    
                    
               </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master',['title'=>'Mero Discount'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/merodisc/laravel/resources/views/front/contactus.blade.php ENDPATH**/ ?>