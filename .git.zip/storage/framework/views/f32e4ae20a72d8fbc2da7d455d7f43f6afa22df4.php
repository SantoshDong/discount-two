
<?php $__env->startSection('content'); ?>
  

<div class="animated fadeIn">
<div class="row">
                <!-- <div class="col-md-1">
                </div> -->
                <div class="col-md-12">

       <?php if(session()->has('success')): ?>

          <div class="alert alert-success alert-dismissible">
           <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <strong><?php echo e(session()->get('success')); ?></strong> 
             </div>


<?php endif; ?>
</div>
</div>

<div class="row">
  <div class="col-lg-12">
    <div class="card">
        <div class="card-header">
            <strong class="card-title">Edit Product's data</strong>
        </div>
        <div class="card-body">
          <!-- Credit Card -->
          <div id="pay-invoice">
              <div class="card-body">
               
                  <form action="<?php echo e(route('product.update',$product->id)); ?>" method="post" novalidate="novalidate" enctype="multipart/form-data">
                    <?php echo method_field('PUT'); ?>
                     <?php echo csrf_field(); ?>
                     <div class="form-group">
                         <label for="cc-payment" class="control-label mb-1"> Product name:</label>
                          <input id="title" name="name" placeholder="Enter the Product name" type="text" class="form-control" aria-required="true" aria-invalid="false" value="<?php echo e($product->name); ?>">      
                      </div>
                    
                      <div class="form-group">
                       <label for="content">Body</label>
        <textarea class="form-control" cols="5" rows="7" placeholder="Enter the description" name="body"><?php echo e($product->body); ?></textarea>                  
                         </div>
                     
                         <div class="form-group">
                         <label for="cc-payment" class="control-label mb-1">Location:</label>
                          <input id="title" placeholder="Enter the Location" value="<?php echo e($product->location); ?>" name="location" type="text" class="form-control" aria-required="true" aria-invalid="false">      
                      </div>

                      <div class="form-group">
                       <label for="content">Address</label>
                    <textarea class="form-control" placeholder="Enter the address" cols="5" rows="7" name="address"><?php echo e($product->address); ?></textarea>                  
                         </div>

                        <div class="form-group">
                        <label for="cc-payment" class="control-label mb-1">Extra field:</label>
                        <input id="title" placeholder="Enter the Extra things" value="<?php echo e($product->remark); ?>" name="extrafield" type="text" class="form-control" aria-required="true" aria-invalid="false">      
                      </div>
                      
                      <div class="form-group">
                        <label for="cc-payment" class="control-label mb-1">Contact numbers:</label>
                        <input id="text" value="<?php echo e($product->contact_nbr); ?>" placeholder="Enter the Extra Things" name="contact_nbr" type="number" class="form-control" aria-required="true" aria-invalid="false" required>      
                      </div>


                      <div class="form-group has-success">
                        <select name="categorys[]" class="form-control" multiple>
                        <option>Select category</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <option value="<?php echo e($category->id); ?>

              <?php if(isset($product)): ?>
       

              <?php endif; ?>
              
              "><?php echo e($category->category_name); ?></option>
                     
                     
                     
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </div>
                     

                      <div class="form-group has-success">
                          <label for="cc-name" class="control-label mb-1">Product logo:</label>
                          <input id="image" name="productlogo" type="file" class="form-control cc-name valid" data-val="true" data-val-required="Please enter the name on card" autocomplete="cc-name" aria-required="true" aria-invalid="false" aria-describedby="cc-name-error">
                          <span class="help-block field-validation-valid" data-valmsg-for="cc-name" data-valmsg-replace="true"></span>
                      <img src="/storage/<?php echo e($product->logo); ?>" height="50px" width="60px">
                      </div>

                     
                      <div class="form-group">
                      <button type="submit" class="btn btn-success">Update</button>
                      </div>
                      
                      <div>


                      </div>

                   


                  </form>
              </div>
          </div>

        </div>






    </div> <!-- .card -->

  </div><!--/.col-->


</div>



</div>

<script>
$(document).ready(function(){
$("#type").click(function(){
$("$image").hide();

});

});

</script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/merodisc/laravel/resources/views/admin/products/edit.blade.php ENDPATH**/ ?>