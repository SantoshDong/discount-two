
<?php $__env->startSection('content'); ?>
  
<link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

   
 

  
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/lib/datatable/dataTables.bootstrap.min.css')); ?>">
    <!-- <link rel="stylesheet" href="assets/css/bootstrap-select.less"> -->
    





<div class="animated fadeIn">




<div class="row">
                <div class="col-md-12">
                

                <?php if(session()->has('success')): ?>
                

             <div class="alert alert-success alert-dismissible">
           <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <strong><?php echo e(session()->get('success')); ?></strong> 
             </div>
                            
                 
                 <?php endif; ?>

                 <?php if(session()->has('warn')): ?>
<div class="alert alert-danger alert-dismissible">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
<strong><?php echo e(session()->get('warn')); ?></strong> 
</div>
                 <?php endif; ?>

            <a href="<?php echo e(route('coverage.create')); ?>" ><button type="button" class="btn btn-success btn-md"  style="float:right">Add Mediacoverage 
                </button></a>

                </div>
                </div>

                <div class="row">

                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title"><h4>list of mediacoverage data</h4></strong>
                        </div>
                        <div class="card-body">
                  <table id="bootstrap-data-table" class="table table-striped table-bordered">
                    <thead>
                      <tr>
                      <th>SN</th>
                      <th>Title</th>            
                        <th>Description</th>         
                        <!-- <th>Url</th> -->
                        <!-- <th>logo</th> -->
                       
                       
                        <th>Operation</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $coverages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coverage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                    
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($coverage->title); ?></td>
                       
                        <td> <?php echo \Illuminate\Support\Str::words($coverage->description,5); ?></td>
                            <!-- <td><?php echo e($coverage->url); ?></td> -->
                    
                        <!-- <td><img src="/storage/<?php echo e($coverage->logo); ?>" height="50px" width="50px"></td>
                        <br>
                         -->
                      

                        <td>
                        <a href="<?php echo e(route('coverage.edit',$coverage->id)); ?>" data-toggle="tooltip" title="Edit"><button type="button" class="btn btn-success btn-sm">
                             edit </button></a>

                             <a href="<?php echo e(url('admin/coverage/view',$coverage->id)); ?>" data-toggle="tooltip" title="view"><button type="button" class="btn btn-primary btn-sm">
                             view </button></a>
                               
                             <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#deleteModal" onclick="handleDelete(<?php echo e($coverage->id); ?>)">
                                 Delete
                                  </button>                       
                                      </td>
                        
                       
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                        </div>
                    </div>
                </div>


                </div>



            </div>
            
     <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
  
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Are you sure want to delete this ?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

     
      <div class="modal-footer">
        <button type="button" class="btn btn-success" data-dismiss="modal" style="color:white;padding:5px;width:10%">No</button>
         <form method="post" action="" id="deleteCategoryForm">
   <?php echo method_field('DELETE'); ?>
   <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-danger" id="deleteBtn">Yes</button>
        </form>
      </div>
    </div>


  </div>
</div> 




<script>
 function handleDelete(id){
   console.log('deleted.',id);
   var form=document.getElementById('deleteCategoryForm')
   form.action='/admin/coverage/' + id
   console.log('deleted.',form);
   $("#deleteModal").modal('show');
 }
 </script>


      
    <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
  
   


    <script src="<?php echo e(asset('assets/js/lib/data-table/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/data-table/dataTables.bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/data-table/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/data-table/buttons.bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/data-table/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/data-table/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/data-table/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/data-table/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/data-table/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/data-table/buttons.colVis.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/data-table/datatables-init.js')); ?>"></script>


    <script type="text/javascript">
        $(document).ready(function() {
          $('#bootstrap-data-table-export').DataTable();
        } );
    </script>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/merodisc/laravel/resources/views/admin/news/index.blade.php ENDPATH**/ ?>