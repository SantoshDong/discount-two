
<?php $__env->startSection('content'); ?>
  

<div class="animated fadeIn">
<div class="row">
                <!-- <div class="col-md-1">
                </div> -->
                <div class="col-md-12">

       <?php if(session()->has('success')): ?>

          <div class="alert alert-success alert-dismissible">
           <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <strong><?php echo e(session()->get('success')); ?></strong> 
             </div>


<?php endif; ?>
</div>
</div>

<div class="row">
  <div class="col-lg-12">
    <div class="card">
        <div class="card-header">
            <strong class="card-title">Add  Mediacoverage</strong>
        </div>
        <div class="card-body">
          <!-- Credit Card -->
          <div id="pay-invoice">
              <div class="card-body">
                               
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
                  <form action="<?php echo e(route('coverage.store')); ?>" method="post" novalidate="novalidate" enctype="multipart/form-data">
                     <?php echo csrf_field(); ?>
                     <div class="form-group">
                          <label for="cc-payment" class="control-label mb-1">Title</label>
                          <input id="title" name="title" type="text" class="form-control" aria-required="true" aria-invalid="false" value="<?php echo e(old('title')); ?>">
                      </div>
                        <div class="form-group">
                       <label for="content">Description</label>
                       <textarea class="form-control" cols="5" rows="7"  placeholder="Enter the address" name="description" required><?php echo e(old('description')); ?></textarea>                  
                         </div>

                      <div class="form-group">
                          <label for="cc-payment" class="control-label mb-1">Url:</label>
                          <input id="title" name="url" type="text" class="form-control" aria-required="true" aria-invalid="false" value="<?php echo e(old('url')); ?>">
                      </div>
                     
                    
                     <div class="form-group has-success">
                          <label for="cc-name" class="control-label mb-1">Image:</label>
                          <input id="image" name="logo" type="file" class="form-control cc-name valid" data-val="true" data-val-required="Please enter the name on card" autocomplete="cc-name" aria-required="true" aria-invalid="false" aria-describedby="cc-name-error" value="<?php echo e(old('logo')); ?>">
                          <span class="help-block field-validation-valid" data-valmsg-for="cc-name" data-valmsg-replace="true"></span>
                      </div>

              
                      <div class="form-group">
                      <button type="submit" class="btn btn-success">submit</button>
                      </div>

                      
                      <div>


                      </div>
                  </form>
              </div>
          </div>

        </div>






    </div> <!-- .card -->

  </div><!--/.col-->


</div>



</div>

<script>
$(document).ready(function(){
$("#type").click(function(){
$("$image").hide();

});

});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/merodisc/laravel/resources/views/admin/news/create.blade.php ENDPATH**/ ?>