
<?php $__env->startSection('content'); ?>
  

<div class="animated fadeIn">
<div class="row">
                <!-- <div class="col-md-1">
                </div> -->
                <div class="col-md-12">

       <?php if(session()->has('success')): ?>

          <div class="alert alert-success alert-dismissible">
           <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <strong><?php echo e(session()->get('success')); ?></strong> 
             </div>


<?php endif; ?>
</div>
</div>

<div class="row">
  <div class="col-lg-12">
    <div class="card">
        <div class="card-header">
            <strong class="card-title">Edit Client's Testimonal</strong>
        </div>
        <div class="card-body">
          <!-- Credit Card -->
          <div id="pay-invoice">
              <div class="card-body">
               
                  <form action="<?php echo e(route('client.update',$client->id)); ?>" method="post" novalidate="novalidate" enctype="multipart/form-data">
                    <?php echo method_field('PUT'); ?>
                     <?php echo csrf_field(); ?>
                      <div class="form-group">

                          <label for="cc-payment" class="control-label mb-1">Name:</label>
                          <input id="title" placeholder="Enter the name" name="name" type="text" class="form-control" aria-required="true" aria-invalid="false" value=" <?php echo e($client->name); ?> ">
                      
                      </div>

                      <div class="form-group">
                       <label for="content">Description</label>
        <textarea class="form-control" cols="5" placeholder="Enter the description" rows="7" name="description"><?php echo e($client->description); ?></textarea>
                      </div>
                    
                      
                     

              

                      <div class="form-group">
                      <button type="submit" class="btn btn-success">Update</button>
                      </div>

                      
                      <div>


                      </div>
                  </form>
              </div>
          </div>

        </div>






    </div> <!-- .card -->

  </div><!--/.col-->


</div>



</div>

<script>
$(document).ready(function(){
$("#type").click(function(){
$("$image").hide();

});

});

</script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/merodisc/laravel/resources/views/admin/client_testimonal/edit.blade.php ENDPATH**/ ?>